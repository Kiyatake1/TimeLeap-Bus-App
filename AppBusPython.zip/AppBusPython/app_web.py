from flask import Flask, render_template, request, send_from_directory, send_file
from olhovivo_api import OlhoVivoAPI
import matplotlib.pyplot as plt
import json
import datetime
import pytz

app = Flask(__name__)

# Token de autenticação
token = "5d8b4007d323f057ba97a7221823fa68128fe36035cf15c1d5caf8dbd1715213"
data_file = '/home/K1y4/AppBusPython/dados.json'  # Nome do arquivo para armazenar os dados do contador de pessoas

# Autenticação
api = OlhoVivoAPI(token)
if not api.autenticar():
    print("Falha na autenticação. Verifique o token fornecido.")
    exit()

# Rota principal
@app.route('/')
def index():
    return render_template('index.html')

# Rota para as outras páginas do site
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_html(path):
    if path.endswith('.html'):
        return render_template(path)
    else:
        return send_from_directory('static', path)

# Rota para busca de linha
@app.route('/buscar_linha', methods=['POST'])
def buscar_linha():
    termos_busca = request.form['termos_busca']
    sentido = request.form['sentido']

    linhas = api.buscar_linha_sentido(termos_busca, sentido)
    titulo = 'Buscar Linha'

    return render_template('resultado.html', titulo=titulo, resultado=linhas)

# Rota para busca de paradas por linha
@app.route('/buscar_paradas', methods=['POST'])
def buscar_paradas():
    codigo_linha = request.form['codigo_linha']

    paradas = api.buscar_paradas_por_linha(codigo_linha)
    titulo = 'Buscar Paradas'

    return render_template('resultado.html', titulo=titulo, resultado=paradas)

# Rota para recebimento de dados na nuvem
@app.route('/receber_dados', methods=['POST'])
def receber_dados():
    data = request.get_json()

    # Salve o JSON em um arquivo
    with open(data_file, 'a') as file:
        json.dump(data, file)
        file.write('\n')  # Adicione uma nova linha para separar os JSONs

    # Gere o gráfico de timestamp x contador
    plotar_grafico()

    # Retorne uma resposta
    return 'Dados recebidos com sucesso'

@app.route('/plotar_grafico', methods=['GET'])
def plotar_grafico():
    timestamps = []
    contadores = []

    # Definir o fuso horário desejado (BRT - Brasília)
    fuso_horario = pytz.timezone('America/Sao_Paulo')

    # Leitura dos dados do arquivo
    with open(data_file, 'r') as file:
        for line in file:
            data = json.loads(line)
            timestamp = data['timestamp']
            dt = datetime.datetime.fromtimestamp(timestamp, fuso_horario)
            hora = dt.strftime('%H:%M:%S')
            timestamps.append(hora)
            contadores.append(data['contador'])

    # Plotagem do gráfico
    plt.plot(timestamps, contadores)
    plt.xlabel('Horário')
    plt.ylabel('Passageiros')
    plt.title('Gráfico de Horário x Passageiros')
    plt.savefig('/home/K1y4/AppBusPython/grafico.png')  # Salvar o gráfico como uma imagem

    # Retornar a imagem como resposta
    return send_file('/home/K1y4/AppBusPython/grafico.png', mimetype='image/png')

# Rota para previsão de chegada de veículos, lotação e Google Maps
@app.route('/previsao_chegada', methods=['POST'])
def previsao_chegada():
    codigo_parada = request.form['codigo_parada']
    codigo_linha = request.form['codigo_linha']

    previsao = api.previsao_parada(codigo_parada, codigo_linha)
    titulo = 'Previsão de Chegada'

    return render_template('resultadoprev.html', titulo=titulo, pr=previsao)

if __name__ == '__main__':
    app.run()
