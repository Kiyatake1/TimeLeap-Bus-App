import requests

class OlhoVivoAPI:
    def __init__(self, token):
        self.base_url = "http://api.olhovivo.sptrans.com.br/v2.1"
        self.token = token
        self.cookie = None

    def autenticar(self):
        try:
            response = requests.post(
                f"{self.base_url}/Login/Autenticar?token={self.token}"
            )
            if response.status_code == 200:
                self.cookie = response.cookies["apiCredentials"]
                return True
            else:
                return False
        except requests.exceptions.RequestException:
            return False

    def buscar_linha_sentido(self, termos_busca, sentido):
        if self.cookie:
            try:
                response = requests.get(
                    f"{self.base_url}/Linha/BuscarLinhaSentido",
                    params={"termosBusca": termos_busca, "sentido": sentido},
                    headers={"Cookie": f"apiCredentials={self.cookie}"},
                )
                if response.status_code == 200:
                    return response.json()
                else:
                    return None
            except requests.exceptions.RequestException:
                return None
        else:
            return None

    def buscar_paradas_por_linha(self, codigo_linha):
        if self.cookie:
            try:
                response = requests.get(
                    f"{self.base_url}/Parada/BuscarParadasPorLinha",
                    params={"codigoLinha": codigo_linha},
                    headers={"Cookie": f"apiCredentials={self.cookie}"},
                )
                if response.status_code == 200:
                    return response.json()
                else:
                    return None
            except requests.exceptions.RequestException:
                return None
        else:
            return None

    def previsao_parada(self, codigo_parada, codigo_linha):
        if self.cookie:
            try:
                response = requests.get(
                    f"{self.base_url}/Previsao",
                    params={"codigoParada": codigo_parada, "codigoLinha": codigo_linha},
                    headers={"Cookie": f"apiCredentials={self.cookie}"},
                )
                if response.status_code == 200:
                    return response.json()
                else:
                    return None
            except requests.exceptions.RequestException:
                return None
        else:
            return None

    def formatar_linhas(self, linhas):
        if linhas:
            for linha in linhas:
                print(f"Código identificador da linha: {linha.get('cl')}")
                print(f"Letreiro completo: {linha.get('lc')}")
                print(f"Sentido de operação: {linha.get('sl')}")
                print("----------------------")
        else:
            print("Nenhuma linha encontrada com os termos de busca e sentido informados.")

    def formatar_paradas(self, paradas):
        if paradas:
            for parada in paradas:
                print(f"Código identificador da parada: {parada.get('cp')}")
                print(f"Nome da parada: {parada.get('np')}")
                print(f"Informação de latitude da localização da parada: {parada.get('py')}")
                print(f"Informação de longitude da localização da parada: {parada.get('px')}")
                print("----------------------")
        else:
            print("Erro ao obter as paradas da linha.")

    def formatar_previsao(self, previsao):
        if previsao is not None and previsao.get("hr") is not None:
            print("---- Previsão de Chegada dos Veículos ----")
            print(f"Horário de referência: {previsao.get('hr')}")
            print(f"Nome da parada: {previsao['p'].get('np')}")
            print(f"Informação de latitude da localização da parada: {previsao['p'].get('py')}")
            print(f"Informação de longitude da localização da parada: {previsao['p'].get('px')}")
            print("----------------------")
            linhas = previsao['p'].get("l")
            if linhas:
                for linha in linhas:
                    print(f"Letreiro completo: {linha.get('c')}")
                    print(f"Código identificador da linha: {linha.get('cl')}")
                    print(f"Sentido de operação: {linha.get('sl')}")
                    print(f"Letreiro de destino da linha: {linha.get('lt0')}")
                    print(f"Letreiro de origem da linha: {linha.get('lt1')}")
                    print(f"Quantidade de veículos localizados: {linha.get('qv')}")
                    print("----------------------")
                    veiculos = linha.get("vs")
                    if veiculos:
                        for veiculo in veiculos:
                            print(f"Prefixo do veículo: {veiculo.get('p')}")
                            print(f"Horário previsto para chegada: {veiculo.get('t')}")
                            print(f"Veículo acessível para pessoas com deficiência: {veiculo.get('a')}")
                            print(f"Horário de localização do veículo: {veiculo.get('ta')}")
                            print(f"Informação de latitude da localização do veículo: {veiculo.get('py')}")
                            print(f"Informação de longitude da localização do veículo: {veiculo.get('px')}")
                            print("----------------------")
                    else:
                        print("Previsão indisponível para a linha.")
            else:
                print("Previsão indisponível para a linha.")
        else:
            print("Previsão indisponível para a parada e linha informadas.")
